#ifndef DEFS_H
#define DEFS_H

#define SCREEN_W 1000
#define SCREEN_H 400

#endif
