#include "Header.h"

SDL_Rect portion;
SDL_Surface *wholeMap;
int x;
int y;
Map m;
void loadLevels()
{
    strcpy(m.mapFile, "image/background.bmp");
    strcpy(m.mapCollision, "image/map1collision.jpg");
}

void startGame(SDL_Surface *screen)
{
    screen = SDL_SetVideoMode(1280, 600, 0, SDL_SWSURFACE);

    initHero(1);

    SDL_EnableKeyRepeat(20, 20);

    wholeMap = IMG_Load(m.mapFile);
    SDL_Surface *untouched = IMG_Load(m.mapFile);
    portion.w = 1280;
    portion.h = 600;
    portion.x = 0;
    portion.y = 0;

    SDL_Event event;

    while (1)
    {
        SDL_BlitSurface(untouched, NULL, wholeMap, NULL);
        SDL_BlitSurface(wholeMap, &portion, screen, NULL);
        showHero(screen);
        SDL_Flip(screen);
        SDL_WaitEvent(&event);

        if (event.type == SDL_QUIT)
        {
            exit(1);
        }
        else if (event.type == SDL_KEYDOWN)
        {
            if (event.key.keysym.sym == SDLK_ESCAPE)
            {
                screen = SDL_SetVideoMode(800, 600, 0, SDL_SWSURFACE | SDL_DOUBLEBUF);
                paintMenu(screen);
            }
            else if (event.key.keysym.sym == SDLK_RIGHT)
            {
                moveHero(right);
            }
            else if (event.key.keysym.sym == SDLK_DOWN)
            {
                moveHero(down);
            }
            else if (event.key.keysym.sym == SDLK_LEFT)
            {
                moveHero(left);
            }
            else if (event.key.keysym.sym == SDLK_UP)
            {
                moveHero(up);
            }
            SDL_Rect heroPos;
            heroPos.x = x;
            heroPos.y = y;
            heroPos.w = posHero.w;
            heroPos.h = posHero.h;
            /*else if(event.key.keysym.sym == SDLK_SPACE)
            {
                printf("%d:%d\n", x,y);
            }*/
        }
    }
}
void scroll(direction d)
{
    if (d == up)
    {
        portion.y -= 5;
        y -= 5;
    }
    else if (d == down)
    {
        portion.y += 5;
        y += 5;
    }
    else if (d == right)
    {
        portion.x += 5;
        x += 5;
    }
    else if (d == left)
    {
        portion.x -= 5;
        x -= 5;
    }
}
int getMapPosX()
{
    return portion.x;
}
int getMapPosY()
{
    return portion.y;
}
int getMapW()
{
    return wholeMap->w;
}
int getMapH()
{
    return wholeMap->h;
}
