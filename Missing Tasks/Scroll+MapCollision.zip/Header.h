#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_rotozoom.h"
#include "SDL/SDL_mixer.h"
#include "SDL/SDL_ttf.h"

typedef enum
{
	up,
	down,
	right,
	left,
} direction;

typedef struct
{
	SDL_Surface *upImage[4];
	SDL_Surface *downImage[4];
	SDL_Surface *rightImage[4];
	SDL_Surface *leftImage[4];
} Hero;

typedef struct
{
	char mapFile[50];
	char mapCollision[50];
} Map;

void initEverything();
void closeEverything();

void paintMenu(SDL_Surface *screen);
void startGame(SDL_Surface *screen);

void initHero(int ID);
void loadHeros();
void showHero(SDL_Surface *screen);
void moveHero(direction dir);
void pathToHero(int enemyIndex);
extern Hero currentHero;

void loadLevels();
extern Map m;

void scroll(direction d);

int getMapPosX();
int getMapPosY();
int getMapW();
int getMapH();
bool collisionmap(direction d, int collX, int collY);
bool collision(SDL_Rect *rect1, SDL_Rect *rect2);
void initCollisionMap();
extern int x;
extern int y;
extern SDL_Rect posHero;